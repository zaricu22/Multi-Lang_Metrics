DISCLAIMER

Plugins are not provided by SonarSource and are therefore installed at your own risk. SonarSource disclaims all liability for installing and using such plugins.


COMMUNITY EDITION

Administrators can either:

- install additional plugins from the Marketplace within the SonarQube UI (Administration > Marketplace)
- download them manually and upload them to this folder (requires SonarQube to be restarted)


DEVELOPER EDITION OR ABOVE

Administrators can install additional plugins by downloading them manually, and uploading them to this folder. You will need to restart SonarQube.

Note that you cannot install any plugins via the SonarQube UI, but you can still explore available plugins (Administration > Marketplace).
